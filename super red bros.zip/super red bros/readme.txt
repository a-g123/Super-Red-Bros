Game: Super Red Bros

Objective: Complete all the levels while avoiding obstacles. The goal is to get to the door and pass the levels.

*there are three levels*

Keys of Use:
space: starts the game
left key and 'a' key: moves the player left
right key and 'd' key: moves the player right
up key and 'w' key: makes the player jump

Obstacles:
spikeball: at random points in the games a spikeball will fall directly above the player - user objective to avoid them by moving left or right
ghost: ghosts move up and down - user objective to avoid them
holes: the map in level 2 and 3 has holes - user objective to jump over them